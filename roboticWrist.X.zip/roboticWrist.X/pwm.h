#ifndef PWM_H
#define	PWM_H
#include <xc.h>

void pwm_start(void);


#endif	/* PWM_H */

