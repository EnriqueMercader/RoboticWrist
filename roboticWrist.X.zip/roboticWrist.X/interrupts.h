#ifndef INTERRUPTS_H
#define	INTERRUPTS_H
    /* Includes */
    #include <xc.h>

    /* Function prototypes */
    void interrupts_Configuration(void);
        
#endif	/* INTERRUPTS_H */

